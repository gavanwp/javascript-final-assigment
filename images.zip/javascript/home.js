let friends = ()=>{
    window.location.assign("../pages/friends.html")
}