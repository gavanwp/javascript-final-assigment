let home = ()=>{
    window.location.assign("../pages/home.html")
}